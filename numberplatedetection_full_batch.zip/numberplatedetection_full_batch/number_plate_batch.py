import cv2
import pytesseract
import os

# Update if Tesseract installed elsewhere
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

plate_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")

image_folder = "images"
if not os.path.exists(image_folder):
    print(f"Error: '{image_folder}' folder not found.")
    raise SystemExit

for file in os.listdir(image_folder):
    if file.lower().endswith(('.jpg', '.jpeg', '.png')):
        path = os.path.join(image_folder, file)
        img = cv2.imread(path)
        if img is None:
            print(f"Could not read {file}, skipping...")
            continue

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        plates = plate_cascade.detectMultiScale(gray, 1.1, 4)

        if len(plates) == 0:
            print(f"{file}: No plate detected")
        for (x, y, w, h) in plates:
            roi = img[y:y+h, x:x+w]
            text = pytesseract.image_to_string(roi, config='--psm 8')
            print(f"{file}: {text.strip()}")
            cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)

        cv2.imshow("Batch Detection", img)
        cv2.waitKey(1000)

cv2.destroyAllWindows()
