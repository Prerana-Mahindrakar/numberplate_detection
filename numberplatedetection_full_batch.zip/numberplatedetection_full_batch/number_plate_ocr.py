import cv2
import pytesseract

# Update if Tesseract installed elsewhere
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

plate_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")

img = cv2.imread("images/car1.jpg")
if img is None:
    print("Error: put an image at images/car1.jpg")
    raise SystemExit

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
plates = plate_cascade.detectMultiScale(gray, 1.1, 4)

for (x, y, w, h) in plates:
    roi = img[y:y+h, x:x+w]
    text = pytesseract.image_to_string(roi, config='--psm 8')
    print("Detected Plate Number:", text.strip())
    cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 3)

cv2.imshow("Plate OCR", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
